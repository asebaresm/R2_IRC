#! /bin/bash

clear
killall G-2361-07-P1-Server
make clean
make
./G-2361-07-P1-Server 


