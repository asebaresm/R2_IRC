var searchData=
[
  ['size',['SIZE',['../_g-2361-06-_p1-_server_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;G-2361-06-P1-Server.h'],['../_g-2361-06-_p1-_sockets_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;G-2361-06-P1-Sockets.h']]]
];
