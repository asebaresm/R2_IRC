var searchData=
[
  ['real',['real',['../_g-2361-06-_p1-_server_8c.html#af832f551e1c343666c3d2a55834139a0',1,'G-2361-06-P1-Server.c']]],
  ['realname',['realname',['../_g-2361-06-_p1-_server_8c.html#a980ab011cd3d327b370c042833f1dc08',1,'G-2361-06-P1-Server.c']]]
];
