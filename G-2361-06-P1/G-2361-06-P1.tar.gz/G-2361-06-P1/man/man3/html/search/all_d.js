var searchData=
[
  ['server1',['server1',['../_g-2361-06-_p1-_server_8c.html#a9045e9ee0087b60273244cd6c2f91a5f',1,'G-2361-06-P1-Server.c']]],
  ['server2',['server2',['../_g-2361-06-_p1-_server_8c.html#a70dd311bef3d0b4160a7ce0706f8f4cc',1,'G-2361-06-P1-Server.c']]],
  ['serverother',['serverother',['../_g-2361-06-_p1-_server_8c.html#ae6eaaf28b08889a7ec2359f8968d796c',1,'G-2361-06-P1-Server.c']]],
  ['servidor',['servidor',['../_g-2361-06-_p1-_server_8h.html#ae168ee6fdf31fd5ed7d49d45b89a65ed',1,'servidor(int puerto, char *path):&#160;G-2361-06-P1-Server.c'],['../_g-2361-06-_p1-_server_8c.html#ae168ee6fdf31fd5ed7d49d45b89a65ed',1,'servidor(int puerto, char *path):&#160;G-2361-06-P1-Server.c'],['../servidor.html',1,'(Global Namespace)']]],
  ['size',['SIZE',['../_g-2361-06-_p1-_server_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;G-2361-06-P1-Server.h'],['../_g-2361-06-_p1-_sockets_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;G-2361-06-P1-Sockets.h']]],
  ['socketalrm',['socketAlrm',['../_g-2361-06-_p1-_server_8c.html#a882bc4c5a2b02dd85d4716961c4d902f',1,'G-2361-06-P1-Server.c']]],
  ['sockets',['sockets',['../_g-2361-06-_p1-_server_8c.html#a7724e53f22e431d1ecb6516951a172e1',1,'G-2361-06-P1-Server.c']]]
];
