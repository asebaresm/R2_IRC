var searchData=
[
  ['prefijo',['PREFIJO',['../_g-2361-06-_p1-_server_8h.html#a78c658ff923693099f7b621e7c351129',1,'G-2361-06-P1-Server.h']]]
];
