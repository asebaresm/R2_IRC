var searchData=
[
  ['user',['user',['../_g-2361-06-_p1-_server_8c.html#a14871705f45ccdc5bb9f4549efd8e119',1,'G-2361-06-P1-Server.c']]],
  ['user_5fmutex',['user_mutex',['../_g-2361-06-_p1-_server_8c.html#a5dedd07a1144d2ab70b74a8e64b6a7c0',1,'G-2361-06-P1-Server.c']]],
  ['usuario',['usuario',['../_g-2361-06-_p1-_server_8c.html#a0147a5b81499984f9cb00379a8cb84af',1,'G-2361-06-P1-Server.c']]]
];
