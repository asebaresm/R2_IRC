var searchData=
[
  ['num_5fsockets',['NUM_SOCKETS',['../_g-2361-06-_p1-_server_8h.html#a1c803e4ececfb47d2791c9283c85eb00',1,'NUM_SOCKETS():&#160;G-2361-06-P1-Server.h'],['../_g-2361-06-_p1-_sockets_8h.html#a1c803e4ececfb47d2791c9283c85eb00',1,'NUM_SOCKETS():&#160;G-2361-06-P1-Sockets.h']]]
];
