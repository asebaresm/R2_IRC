var searchData=
[
  ['accion',['accion',['../_g-2361-06-_p1-_server_8c.html#a93e785c991445d8b8ee99c2e51242d5a',1,'G-2361-06-P1-Server.c']]],
  ['away',['away',['../_g-2361-06-_p1-_server_8c.html#adf86742e21384f58f8999d8317e6a370',1,'G-2361-06-P1-Server.c']]]
];
