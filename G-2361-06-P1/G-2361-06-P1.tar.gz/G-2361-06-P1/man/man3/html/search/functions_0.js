var searchData=
[
  ['abrir_5fsockettcp',['abrir_socketTCP',['../_g-2361-06-_p1-_sockets_8h.html#af2f55f83053c8fdebb8da511cd65880c',1,'abrir_socketTCP(int puerto):&#160;G-2361-06-P1-Sockets.c'],['../_g-2361-06-_p1-_sockets_8c.html#af2f55f83053c8fdebb8da511cd65880c',1,'abrir_socketTCP(int puerto):&#160;G-2361-06-P1-Sockets.c']]],
  ['acepta_5fconexion',['acepta_conexion',['../_g-2361-06-_p1-_sockets_8h.html#a172e85f036cff044fd5ba218460115c7',1,'acepta_conexion(int IDsocket):&#160;G-2361-06-P1-Sockets.c'],['../_g-2361-06-_p1-_sockets_8c.html#a172e85f036cff044fd5ba218460115c7',1,'acepta_conexion(int IDsocket):&#160;G-2361-06-P1-Sockets.c']]]
];
