var searchData=
[
  ['daemonizar',['daemonizar',['../_g-2361-06-_p1-_daemon_8h.html#ae983f3eb0ff5cebb14c2ae123043df39',1,'daemonizar(char *servicio):&#160;G-2361-06-P1-Daemon.c'],['../_g-2361-06-_p1-_daemon_8c.html#ae983f3eb0ff5cebb14c2ae123043df39',1,'daemonizar(char *servicio):&#160;G-2361-06-P1-Daemon.c']]]
];
