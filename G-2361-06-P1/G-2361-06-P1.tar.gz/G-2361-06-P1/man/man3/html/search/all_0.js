var searchData=
[
  ['abrir_5fsockettcp',['abrir_socketTCP',['../_g-2361-06-_p1-_sockets_8h.html#af2f55f83053c8fdebb8da511cd65880c',1,'abrir_socketTCP(int puerto):&#160;G-2361-06-P1-Sockets.c'],['../_g-2361-06-_p1-_sockets_8c.html#af2f55f83053c8fdebb8da511cd65880c',1,'abrir_socketTCP(int puerto):&#160;G-2361-06-P1-Sockets.c']]],
  ['accion',['accion',['../_g-2361-06-_p1-_server_8c.html#a93e785c991445d8b8ee99c2e51242d5a',1,'G-2361-06-P1-Server.c']]],
  ['acepta_5fconexion',['acepta_conexion',['../_g-2361-06-_p1-_sockets_8h.html#a172e85f036cff044fd5ba218460115c7',1,'acepta_conexion(int IDsocket):&#160;G-2361-06-P1-Sockets.c'],['../_g-2361-06-_p1-_sockets_8c.html#a172e85f036cff044fd5ba218460115c7',1,'acepta_conexion(int IDsocket):&#160;G-2361-06-P1-Sockets.c']]],
  ['away',['away',['../_g-2361-06-_p1-_server_8c.html#adf86742e21384f58f8999d8317e6a370',1,'G-2361-06-P1-Server.c']]]
];
