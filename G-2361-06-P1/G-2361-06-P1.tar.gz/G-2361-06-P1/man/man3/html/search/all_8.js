var searchData=
[
  ['liberalista',['liberaLista',['../_g-2361-06-_p1-_functions_8h.html#a5fa63429b3483f20a469c23625c96820',1,'liberaLista(char **lista, long nElems):&#160;G-2361-06-P1-Functions.c'],['../_g-2361-06-_p1-_functions_8c.html#a5fa63429b3483f20a469c23625c96820',1,'liberaLista(char **lista, long nElems):&#160;G-2361-06-P1-Functions.c'],['../libera_lista.html',1,'(Global Namespace)']]],
  ['listanicks',['listaNicks',['../_g-2361-06-_p1-_server_8c.html#a713172366a6be2fbf8456a4b43702603',1,'G-2361-06-P1-Server.c']]]
];
