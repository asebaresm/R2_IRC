var searchData=
[
  ['daemonizar',['daemonizar',['../daemonizar.html',1,'']]]
];
