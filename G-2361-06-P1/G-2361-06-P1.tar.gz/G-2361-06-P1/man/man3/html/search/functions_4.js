var searchData=
[
  ['main',['main',['../_g-2361-06-_p1-prueba_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'G-2361-06-P1-prueba.c']]],
  ['manejador_5falarma',['manejador_alarma',['../_g-2361-06-_p1-_server_8h.html#ad27ad83298aac3580deda730e80a62f0',1,'G-2361-06-P1-Server.h']]]
];
