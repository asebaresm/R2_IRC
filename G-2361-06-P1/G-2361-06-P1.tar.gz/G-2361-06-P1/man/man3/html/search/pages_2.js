var searchData=
[
  ['liberalista',['liberaLista',['../libera_lista.html',1,'']]]
];
