var searchData=
[
  ['parsecommand',['parseCommand',['../_g-2361-06-_p1-_server_8h.html#ab7e145be74e8922987621cd01b8d446e',1,'parseCommand(long int query, char *comando, int IDsocket):&#160;G-2361-06-P1-Server.c'],['../_g-2361-06-_p1-_server_8c.html#ab7e145be74e8922987621cd01b8d446e',1,'parseCommand(long int query, char *comando, int IDsocket):&#160;G-2361-06-P1-Server.c']]],
  ['procesar',['procesar',['../_g-2361-06-_p1-_server_8h.html#a3053755c82b5168bea9d848b1284f3ca',1,'procesar(char *entrada, int IDsocket, fd_set readset):&#160;G-2361-06-P1-Server.c'],['../_g-2361-06-_p1-_server_8c.html#a3053755c82b5168bea9d848b1284f3ca',1,'procesar(char *entrada, int IDsocket, fd_set readset):&#160;G-2361-06-P1-Server.c']]]
];
