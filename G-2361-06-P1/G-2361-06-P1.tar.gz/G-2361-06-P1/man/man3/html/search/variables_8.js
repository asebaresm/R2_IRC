var searchData=
[
  ['nick',['nick',['../_g-2361-06-_p1-_server_8c.html#a89f27568c92a418413e6b37b41f07e21',1,'G-2361-06-P1-Server.c']]],
  ['nick_5fname',['nick_name',['../_g-2361-06-_p1-_server_8c.html#aabbf66718cda228b924a4a9441eadf62',1,'G-2361-06-P1-Server.c']]],
  ['numerousuarios',['numeroUsuarios',['../_g-2361-06-_p1-_server_8c.html#ac9a5ec6f534d2a8e2a870179807d32dc',1,'G-2361-06-P1-Server.c']]]
];
