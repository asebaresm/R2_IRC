var searchData=
[
  ['liberalista',['liberaLista',['../_g-2361-06-_p1-_functions_8h.html#a5fa63429b3483f20a469c23625c96820',1,'liberaLista(char **lista, long nElems):&#160;G-2361-06-P1-Functions.c'],['../_g-2361-06-_p1-_functions_8c.html#a5fa63429b3483f20a469c23625c96820',1,'liberaLista(char **lista, long nElems):&#160;G-2361-06-P1-Functions.c']]]
];
