var searchData=
[
  ['servidor',['servidor',['../_g-2361-06-_p1-_server_8h.html#ae168ee6fdf31fd5ed7d49d45b89a65ed',1,'servidor(int puerto, char *path):&#160;G-2361-06-P1-Server.c'],['../_g-2361-06-_p1-_server_8c.html#ae168ee6fdf31fd5ed7d49d45b89a65ed',1,'servidor(int puerto, char *path):&#160;G-2361-06-P1-Server.c']]]
];
